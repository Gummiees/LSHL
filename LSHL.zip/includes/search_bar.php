<div class="row search-bar">
	<div class="col-sm-12 text-center horizontal-center">
		<form class="form-inline" role="search">
  		<div class="col-sm-8">
    		<div class="input-group input-group-lg">
          <input type="text" class="form-control" placeholder="Search" name="q">
          <div class="input-group-btn">
            <button class="btn btn-default" type="submit"><span class="fa fa-search" aria-hidden="true"></span></button>
          </div>
    		</div>
			</div>
			<div class="col-sm-4">
    		<div class="input-group input-group-lg">
					<select class="form-control" id="selector" name="s">
					  <option value="new" selected>Newest</option>
					  <option value="old">Oldest</option>
					  <option value="low">Lower Price</option>
					  <option value="high">Higher Price</option>
					</select>
    		</div>
			</div>
    </form>
	</div>
</div>